READ ME

Educational Achievement Schemas ZIP file 

This file contains XSD schemas to validate MedBiquitous Educational Achievement XML data. Please review
The educationalachievement.xsd schema. The educationalachievement.xsd schema imports two schemas 
developed by the Postsecondard Education Standards Council, or PESC. The Educational Achievement schema 
uses data types for education test scores within these two schemas only.

It is NOT necessary to review the AcademicRecord_v1.6.0 and CoreMain_v1.7.0 in their entirety.

The Educational Achievement schema also imports several schemas developed by MedBiquitous, including:

* The Healthcare Professional Profile (including Name and Address)
* Curriculum Inventory
* Competency Framework
* Competency Object
* Healthcare LOM

These schemas are all available through the following website: 
http://ns.medbiq.org

MedBiquitous schemas are referenced via their location on this central server, so downloading them is 
not necessary.

If you have any questions regarding these schemas, please contact Valerie Smothers at 
vsmothers@jhmi.edu.